import math

bitrate = 0 #used to save previous bitrate
prev_m = 3 # as m in range(3), choosing the 3 as the inital value won't affect the result
# gamma*p = 5 #tradeoff between utility and rebuffering given in the paper


def student_entrypoint(Measured_Bandwidth, Previous_Throughput, Buffer_Occupancy, Available_Bitrates, Video_Time, Chunk, Rebuffering_Time, Preferred_Bitrate ):
    #student can do whatever they want from here going forward
    global bitrate
    S_m = list(Available_Bitrates.items())
    S_m.sort(key=lambda tup: tup[1] , reverse=True)
    prev_bitrate = bitrate
    '''
    print("===============================")
    print("Measured Bandwidth: ", Measured_Bandwidth)
    print("Previous_Throughput: ", Previous_Throughput)
    print("Buffer_Occupancy: ", Buffer_Occupancy)
    print("Available_Bitrates,: ", Available_Bitrates)
    print("Video_Time", Video_Time)
    print("Chunk: ", Chunk)
    print("Rebuffering_Time: ", Rebuffering_Time)
    print("Preferred_Bitrate", Preferred_Bitrate)
    print("===============================")
	'''
    #bitrate = bufferbased(rate_prev=bitrate, buf_now= Buffer_Occupancy, r=Chunk['time']+1,R_i= R_i )
    bitrate = BOLA(prev_bitrate, Previous_Throughput, Buffer_Occupancy, S_m, Video_Time, Chunk) 
    return bitrate

#helper function, to find the corresponding size of previous bitrate
def match(value, list_of_list): 
    for e in list_of_list:
        if value == e[1]:
            return e[1]
        
    return list_of_list[-1][1] #for the start case when value = 0
        
'''
For n in [0, N] do 
	t = min[playtime from begin, playtime to end]
	t_bar = max[t/2, 3*p]
	Q_dmax = min[Q_max, t_bar/p]
	V_D = (Q_dmax - 1)/(v1 + gamma*p)
	m[n] = arg max(V_D_max + V_D*gamma*p - Q)/Sm
	if m[n] < m[n-1] then
		r =  bandwidth measured when downloading chunk (n-1)
		m_bar  = min m such that Sm/p <= max[r, Sm/p]
		if m_bar <= m[n] then
			m_bar = m[n]
		else if m_bar > m[n-1] then
			m_bar  = m[n-1]
		else if some utility sacrificed for fewer oscillations then 
			//BOLA-O method
			Pause until (V_D*vm + V_D*gamma*p)/Sm >= (V_D*vm-1 + V_D*gamma*p - Q)/Sm-1

		else #BOLA_U method
			m_bar = m_bar - 1
		end if
		M[n] = m_bar
	end if
	pause for max[p*(Q-Q_dmax +1), 0]
	Download chunk n at bitrate index m[n],possibly abandoning
End for
'''


def BOLA(prev_bitrate,  Previous_Throughput, Buffer_Occupancy, S_m,  Video_Time, Chunk):
    #Q_max = int(Buffer_Occupancy['size'])

    # global variable to store the previous bitrate index
    global prev_m
    '''
    print("prev_bitrate: ", prev_bitrate)
    print("S_m: ", S_m)
    print("match(prev_bitrate, S_m): ", match(prev_bitrate, S_m))
    '''
    # calculate the maximum buffer size in seconds based on the buffer occupancy and the previous bitrate
    Q_max = Buffer_Occupancy['time'] / Chunk['time'] + (Buffer_Occupancy['size'] - Buffer_Occupancy['current']) / match(prev_bitrate, S_m) / Chunk['time']
    

    # utility ln(current bitrate/ min bitrate)
    # minimum utility value
    # calculate the minimum utility value based on the segment sizes
    v1 = math.log(int(S_m[0][0]) / int(S_m[-1][0]), math.e)

    playtime_begin = Video_Time
    playtime_total = int(Chunk['time'])*(int(Chunk['current'])+int(Chunk['left']))
    playtime_end = playtime_total - playtime_begin

    # chunk duration in seconds
    chunk_time = int(Chunk['time'])

    # minimum of the playtime from the begin or end
    t = min(playtime_begin, playtime_end)
    # effective buffer size
    t_bar = max(t/2, 3*int(Chunk['time']))
    # desired buffer level
    Q_Dmax = min(Q_max, t_bar/chunk_time) 

    # buffer-dependent utility value
    V_D = (Q_Dmax - 1)/(v1 + 5)

    # argmax index m 
    # calculate the optimal bitrate index that maximizes the utility function
    m = max(range(len(S_m)) , key = lambda index : (V_D * math.log(int(S_m[index][0]) / int(S_m[-1][0]), math.e) + V_D * 5 - Buffer_Occupancy['time'] / Chunk['time']) / S_m[index][1])

    if m > prev_m:
        r = Previous_Throughput / 8 #convert byte to bit
        # initialize the minimum bitrate index that satisfies the bandwidth constraint
        m_bar = 0
        for i in range(len(S_m)):
            # find the chunk size id smaller or equal to the previous throughput or minimum bitrate chunk
            if S_m[i][1] <= max(r, S_m[-1][1]):
                m_bar = i
                break
        if m_bar <= m:
            m_bar = m
        elif m_bar > prev_m:
            # keep the same bitrate index as the previous one
            m_bar = prev_m
        
        m = m_bar

    prev_m = m # update the previous bitrate index

    return S_m[m][0]


    
